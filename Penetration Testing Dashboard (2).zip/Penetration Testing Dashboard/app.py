from flask import Flask, render_template, jsonify, request
import socket
import json
import os
import requests
from datetime import datetime

app = Flask(__name__, static_folder='static', template_folder='templates')

TARGETS = []
VULNERABILITIES = []
SCAN_HISTORY = []
audit_counter = 0

# Port-to-Service mapping configured specifically for Metasploitable 2 (Ubuntu 8.04 SysVinit)
PORT_PROFILES = {
    21: {
        "service": "FTP",
        "title": "vsftpd 2.3.4 Backdoor Signature",
        "severity": "Critical",
        "cvss": "9.8",
        "cve": "CVE-2011-2523",
        "cisa_kev": True,
        "details": "The FTP daemon banner exposes vsftpd 2.3.4. This build contains a malicious backdoor that spawns a root shell on port 6200 when a smiley face ':)' is sent in the username.",
        "remediation": "# Stop the xinetd internet superserver managing FTP on Metasploitable:\nsudo /etc/init.d/xinetd stop\n\n# Ensure all lingering vsftpd processes are terminated:\nsudo killall -9 vsftpd",
        "verification_cmd": "netstat -tuln | grep :21  # Should return blank"
    },
    23: {
        "service": "Telnet",
        "title": "Insecure Telnet Remote Access Active",
        "severity": "High",
        "cvss": "7.5",
        "cve": "CWE-319",
        "cisa_kev": False,
        "details": "Cleartext Telnet daemon detected. Authentication passwords and shell commands travel across the local network unencrypted.",
        "remediation": "# Telnet is managed by xinetd / openbsd-inetd. Stop the service:\nsudo /etc/init.d/openbsd-inetd stop\nsudo /etc/init.d/xinetd stop",
        "verification_cmd": "netstat -tuln | grep :23  # Should return blank"
    },
    80: {
        "service": "HTTP",
        "title": "HTTP Cleartext Communication Allowed",
        "severity": "Low",
        "cvss": "3.5",
        "cve": "CWE-311",
        "cisa_kev": False,
        "details": "Apache web server serves unencrypted plaintext HTTP without mandatory TLS/HTTPS encryption.",
        "remediation": "# Stop the Apache web server daemon:\nsudo /etc/init.d/apache2 stop",
        "verification_cmd": "netstat -tuln | grep :80  # Should return blank"
    },
    139: {
        "service": "NetBIOS-SSN",
        "title": "Samba username map script Vulnerability",
        "severity": "High",
        "cvss": "8.5",
        "cve": "CVE-2007-2447",
        "cisa_kev": True,
        "details": "Samba 3.0.20 listens on TCP 139/445 and is vulnerable to unauthenticated remote command execution through the username parameter.",
        "remediation": "# Stop the Samba file sharing service:\nsudo /etc/init.d/samba stop",
        "verification_cmd": "netstat -tuln | grep -E '139|445'  # Should return blank"
    },
    445: {
        "service": "SMB",
        "title": "SMB Remote Command Execution Surface",
        "severity": "High",
        "cvss": "8.5",
        "cve": "CVE-2007-2447",
        "cisa_kev": True,
        "details": "Exposed SMB file-sharing listener allows unauthenticated network clients to map shares and execute commands.",
        "remediation": "# Stop the Samba service daemon:\nsudo /etc/init.d/samba stop",
        "verification_cmd": "netstat -tuln | grep :445  # Should return blank"
    },
    3306: {
        "service": "MySQL",
        "title": "Exposed Database Listener (MySQL)",
        "severity": "High",
        "cvss": "7.2",
        "cve": "CWE-668",
        "cisa_kev": False,
        "details": "MySQL database server is listening on all public network interfaces (0.0.0.0) without host firewall restrictions.",
        "remediation": "# Stop the MySQL database server daemon:\nsudo /etc/init.d/mysql stop",
        "verification_cmd": "netstat -tuln | grep :3306  # Should return blank"
    }
}

def probe_network_port(ip, port, timeout=0.8):
    """Performs a real TCP socket check and banner grab."""
    banner = ""
    is_open = False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        code = s.connect_ex((ip, port))
        if code == 0:
            is_open = True
            try:
                s.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                raw = s.recv(256)
                banner = raw.decode(errors='ignore').strip().replace("\n", " ")[:120]
            except Exception:
                banner = f"Service responded on TCP port {port}"
        s.close()
    except Exception as e:
        banner = str(e)
    return is_open, banner

def calculate_security_score():
    """Computes a dynamic Security Posture Score between 10% and 100%."""
    if not VULNERABILITIES:
        return 100
    penalty = 0
    for v in VULNERABILITIES:
        if v.get("status") == "Open":
            sev = v.get("severity")
            if sev == "Critical":
                penalty += 25
            elif sev == "High":
                penalty += 15
            elif sev == "Medium":
                penalty += 8
            else:
                penalty += 4
    return max(10, 100 - penalty)

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    resolved_count = len([v for v in VULNERABILITIES if v.get("status") == "Mitigated"])
    return jsonify({
        "totalTargets": len(TARGETS),
        "totalFindings": len(VULNERABILITIES),
        "resolvedFindings": resolved_count,
        "totalAudits": audit_counter,
        "securityScore": calculate_security_score(),
        "recentActivity": SCAN_HISTORY[-4:] if SCAN_HISTORY else []
    })

@app.route('/api/targets', methods=['GET', 'POST'])
def handle_targets():
    global TARGETS
    if request.method == 'POST':
        data = request.json or {}
        target_ip = data.get("ip", "127.0.0.1").strip()
        
        scope_valid = not (target_ip.startswith("127.") or target_ip == "0.0.0.0")
        
        new_id = (max([t["id"] for t in TARGETS], default=0) + 1)
        new_target = {
            "id": new_id,
            "name": data.get("name", f"Target-{new_id}"),
            "ip": target_ip,
            "scope": data.get("scope", "Authorized Lab"),
            "status": "Online",
            "scopeValid": scope_valid
        }
        TARGETS.append(new_target)
        SCAN_HISTORY.append({
            "title": f"Target Enrolled: {new_target['name']}",
            "time": datetime.now().strftime("%H:%M:%S"),
            "type": "target"
        })
        return jsonify(new_target), 201

    return jsonify(TARGETS)

@app.route('/api/targets/<int:target_id>', methods=['DELETE'])
def delete_target(target_id):
    global TARGETS, VULNERABILITIES
    TARGETS = [t for t in TARGETS if t["id"] != target_id]
    VULNERABILITIES = [v for v in VULNERABILITIES if v.get("targetId") != target_id]
    return jsonify({"success": True})

@app.route('/api/vulnerabilities', methods=['GET'])
def get_vulnerabilities():
    return jsonify(VULNERABILITIES)

@app.route('/api/vulnerabilities/<int:vuln_id>/verify', methods=['POST'])
def verify_vulnerability(vuln_id):
    """Probes the live target port to confirm if the fix was applied."""
    vuln = next((v for v in VULNERABILITIES if v["id"] == vuln_id), None)
    if not vuln:
        return jsonify({"error": "Finding not found"}), 404

    target = next((t for t in TARGETS if t["id"] == vuln.get("targetId")), None)
    if not target:
        return jsonify({"error": "Target not found"}), 404

    is_open, _ = probe_network_port(target["ip"], vuln["port"])
    
    if not is_open:
        vuln["status"] = "Mitigated"
        SCAN_HISTORY.append({
            "title": f"Mitigation Verified: {vuln.get('title')} (Port {vuln['port']} closed)",
            "time": datetime.now().strftime("%H:%M:%S"),
            "type": "status"
        })
        return jsonify({
            "success": True,
            "closed": True,
            "message": f"Port {vuln['port']} is closed! Finding marked as Mitigated.",
            "newStatus": "Mitigated",
            "securityScore": calculate_security_score()
        })
    else:
        return jsonify({
            "success": False,
            "closed": False,
            "message": f"Port {vuln['port']} is still OPEN on {target['ip']}. Run the stop command on your VM first.",
            "newStatus": vuln["status"],
            "securityScore": calculate_security_score()
        })

@app.route('/api/vulnerabilities/<int:vuln_id>/toggle', methods=['POST'])
def toggle_status(vuln_id):
    for v in VULNERABILITIES:
        if v["id"] == vuln_id:
            v["status"] = "Mitigated" if v.get("status") == "Open" else "Open"
            SCAN_HISTORY.append({
                "title": f"Status Changed: {v.get('title')} -> {v['status']}",
                "time": datetime.now().strftime("%H:%M:%S"),
                "type": "status"
            })
            return jsonify({"success": True, "newStatus": v["status"], "securityScore": calculate_security_score()})
    return jsonify({"error": "Finding not found"}), 404

@app.route('/api/audit/<int:target_id>', methods=['POST'])
def run_audit(target_id):
    global audit_counter, VULNERABILITIES
    audit_counter += 1
    target = next((t for t in TARGETS if t["id"] == target_id), None)
    
    if not target:
        return jsonify({"error": "Target not found"}), 404

    target_ip = target["ip"]
    detected_vulns = []
    
    open_ports = []
    port_evidence = {}
    for port in PORT_PROFILES.keys():
        is_open, banner = probe_network_port(target_ip, port)
        if is_open:
            open_ports.append(port)
            port_evidence[port] = banner

    # Clean old findings for this target to reflect real-time network state
    VULNERABILITIES = [v for v in VULNERABILITIES if v.get("targetId") != target_id]

    for port in open_ports:
        profile = PORT_PROFILES.get(port, {})
        evidence_text = port_evidence.get(port, f"Active listener identified on port {port}/TCP.")
        
        new_vuln = {
            "id": len(VULNERABILITIES) + 1,
            "targetId": target["id"],
            "targetName": target["name"],
            "port": port,
            "service": profile.get("service", "Unknown"),
            "severity": profile.get("severity", "Low"),
            "cvss": profile.get("cvss", "0.0"),
            "title": profile.get("title", f"Exposed Port {port}"),
            "cve": profile.get("cve", "N/A"),
            "cisa_kev": profile.get("cisa_kev", False),
            "details": profile.get("details", "Service listener discovered during scan."),
            "evidence": evidence_text,
            "remediation": profile.get("remediation", "Stop the service or block the port."),
            "verification_cmd": profile.get("verification_cmd", f"netstat -tuln | grep :{port}"),
            "status": "Open",
            "auditTimestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        VULNERABILITIES.append(new_vuln)
        detected_vulns.append(new_vuln)

    SCAN_HISTORY.append({
        "title": f"Scan Complete for {target['name']} ({len(detected_vulns)} findings)",
        "time": datetime.now().strftime("%H:%M:%S"),
        "type": "scan"
    })

    return jsonify({
        "success": True,
        "message": f"Scan completed for {target['name']}",
        "openPorts": open_ports,
        "findingsCount": len(detected_vulns),
        "securityScore": calculate_security_score()
    })

@app.route('/api/ai-advisor/<int:vuln_id>', methods=['GET'])
def ai_advisor(vuln_id):
    finding = next((v for v in VULNERABILITIES if v["id"] == vuln_id), None)
    if not finding:
        return jsonify({"error": "Finding not found"}), 404

    cve = finding.get("cve", "N/A")
    port = finding.get("port", "Unknown")
    service = finding.get("service", "Network Service")
    
    ai_analysis = {
        "finding": finding.get("title", "Unknown"),
        "cve": cve,
        "threatActorObjective": f"Attackers scan for exposed port {port} ({service}) to exploit outdated software, gain remote shell access, or steal data.",
        "attackVector": f"Direct TCP connection to target port {port}.",
        "cisaExploitedInWild": finding.get("cisa_kev", False),
        "fixSteps": [
            f"1. Open your Metasploitable 2 terminal window.",
            f"2. Stop the vulnerable service using the exact SysVinit command below.",
            f"3. Verify that port {port} is closed with 'netstat -tuln | grep :{port}'.",
            f"4. Click 'Verify & Close' in the dashboard to confirm the fix."
        ],
        "hardeningScript": finding.get("remediation", ""),
        "verificationCmd": finding.get("verification_cmd", f"netstat -tuln | grep :{port}")
    }

    return jsonify(ai_analysis)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)