let localTargets = [];
let localFindings = [];

async function loadDashboard() {
  try {
    const metricsRes = await fetch('/api/metrics');
    const metrics = await metricsRes.json();
    document.getElementById('totalTargets').innerText = metrics.totalTargets;
    document.getElementById('totalFindings').innerText = metrics.totalFindings;
    document.getElementById('resolvedFindings').innerText = metrics.resolvedFindings;
    document.getElementById('totalAudits').innerText = metrics.totalAudits;
    
    const scoreElem = document.getElementById('securityScoreBadge');
    scoreElem.innerText = `${metrics.securityScore}%`;
    scoreElem.style.color = metrics.securityScore > 75 ? '#34d399' : (metrics.securityScore > 50 ? '#fbbf24' : '#f87171');

    const targetsRes = await fetch('/api/targets');
    localTargets = await targetsRes.json();
    renderTargets(localTargets);

    const vulnRes = await fetch('/api/vulnerabilities');
    localFindings = await vulnRes.json();
    renderFindings(localFindings);

    updateStepperState();
  } catch (err) {
    console.error("Dashboard synchronization error:", err);
  }
}

function updateStepperState() {
  const hasTargets = localTargets.length > 0;
  const hasFindings = localFindings.length > 0;
  const hasMitigations = localFindings.some(f => f.status === 'Mitigated');

  setStepStatus('step-1', hasTargets);
  setStepStatus('step-2', hasTargets);
  setStepStatus('step-3', hasFindings);
  setStepStatus('step-4', hasFindings);
  setStepStatus('step-5', hasMitigations);
  setStepStatus('step-6', hasFindings);
}

function setStepStatus(stepId, isComplete) {
  const el = document.getElementById(stepId);
  if (!el) return;
  if (isComplete) {
    el.className = 'step-item completed';
    el.querySelector('.step-icon').innerText = '✓';
  } else {
    el.className = 'step-item';
    el.querySelector('.step-icon').innerText = '○';
  }
}

function renderTargets(targets) {
  const tbody = document.getElementById('targetTableBody');
  const emptyMsg = document.getElementById('targetEmpty');
  tbody.innerHTML = '';

  if (targets.length === 0) {
    emptyMsg.style.display = 'block';
    return;
  }
  emptyMsg.style.display = 'none';

  targets.forEach(t => {
    const scopeBadge = t.scopeValid !== false 
      ? '<span style="color:#10b981;">✓ Authorized</span>' 
      : '<span style="color:#ef4444;">⚠ Out of Scope</span>';

    tbody.innerHTML += `
      <tr>
        <td><strong>${t.name}</strong></td>
        <td><code>${t.ip}</code></td>
        <td>${t.scope} (${scopeBadge})</td>
        <td><span style="color:#10b981;">● ${t.status}</span></td>
        <td>
          <button class="btn btn-purple" onclick="triggerAudit(${t.id}, '${t.name}')">Scan & Audit</button>
          <button class="btn btn-red" onclick="removeTarget(${t.id})" style="margin-left:4px;">Remove</button>
        </td>
      </tr>
    `;
  });
}

function renderFindings(findings) {
  const tbody = document.getElementById('vulnTableBody');
  const emptyMsg = document.getElementById('vulnEmpty');
  tbody.innerHTML = '';
  const filter = document.getElementById('filterSeverity').value;

  const filtered = findings.filter(f => filter === 'ALL' || f.severity === filter);

  if (filtered.length === 0) {
    emptyMsg.style.display = 'block';
    return;
  }
  emptyMsg.style.display = 'none';

  filtered.forEach(f => {
    const kevBadge = f.cisa_kev ? '<span class="badge badge-cisa">CISA KEV: IN WILD</span>' : '';
    const isMitigated = f.status === 'Mitigated';

    tbody.innerHTML += `
      <tr>
        <td><span class="badge badge-${f.severity}">${f.severity} (${f.cvss})</span></td>
        <td>
          <strong>${f.title}</strong> ${kevBadge}
          <br><small style="color:#94a3b8;">${f.cve}</small>
        </td>
        <td><code>Port ${f.port || 'N/A'} (${f.service || 'TCP'})</code></td>
        <td style="max-width:260px; font-size:0.75rem; color:#cbd5e1;"><code>${f.evidence || f.details}</code></td>
        <td>
          <button class="status-badge ${isMitigated ? 'mitigated' : ''}" onclick="verifyAndClose(${f.id})">
            ${isMitigated ? '✓ Mitigated' : 'Verify & Close'}
          </button>
        </td>
        <td>
          <button class="btn btn-amber" onclick="openFix(${f.id})">Fix Guide</button>
          <button class="btn btn-purple" onclick="openAiAdvisor(${f.id})" style="margin-left:3px;">AI Advisor</button>
        </td>
      </tr>
    `;
  });
}

async function triggerAudit(id, targetName) {
  const step3 = document.getElementById('step-3');
  const step4 = document.getElementById('step-4');

  step3.className = 'step-item active';
  step3.querySelector('.step-icon').innerText = '⟳';

  try {
    const res = await fetch(`/api/audit/${id}`, { method: 'POST' });
    const data = await res.json();
    
    step3.className = 'step-item completed';
    step3.querySelector('.step-icon').innerText = '✓';
    step4.className = 'step-item completed';
    step4.querySelector('.step-icon').innerText = '✓';

    alert(`Audit finished for ${targetName}! Discovered ${data.findingsCount} open vulnerable service(s).`);
    loadDashboard();
  } catch (err) {
    alert("Audit execution failed. Ensure the Flask server is running.");
  }
}

// Probes the real target port to verify if the remediation was successful
async function verifyAndClose(id) {
  try {
    const res = await fetch(`/api/vulnerabilities/${id}/verify`, { method: 'POST' });
    const data = await res.json();
    
    alert(data.message);
    loadDashboard();
  } catch (err) {
    // Fallback toggle
    const toggleRes = await fetch(`/api/vulnerabilities/${id}/toggle`, { method: 'POST' });
    if (toggleRes.ok) loadDashboard();
  }
}

async function openAiAdvisor(id) {
  const res = await fetch(`/api/ai-advisor/${id}`);
  if (!res.ok) return;
  const data = await res.json();

  document.getElementById('modalTitle').innerText = `🤖 AI Advisor: ${data.finding}`;
  document.getElementById('modalRef').innerText = `Identifier: ${data.cve} | Threat Level: ${data.cisaExploitedInWild ? 'Actively Exploited in the Wild' : 'Known Security Risk'}`;
  
  const aiBox = document.getElementById('aiAdvisorContent');
  aiBox.style.display = 'block';
  document.getElementById('aiObjective').innerText = data.threatActorObjective;

  const stepsContainer = document.getElementById('aiSteps');
  stepsContainer.innerHTML = '<strong>Recommended Walkthrough:</strong><br>' + data.fixSteps.join('<br>');

  document.getElementById('modalCode').innerText = data.hardeningScript;
  document.getElementById('modalVerifyCmd').innerText = data.verificationCmd;
  
  document.getElementById('fixModal').classList.add('active');
}

function openFix(id) {
  const f = localFindings.find(item => item.id === id);
  if (!f) return;
  document.getElementById('modalTitle').innerText = `🛠️ Fix Guide: ${f.title}`;
  document.getElementById('modalRef').innerText = `Port: ${f.port} (${f.service}) | Vulnerability Reference: ${f.cve}`;
  document.getElementById('aiAdvisorContent').style.display = 'none';
  document.getElementById('modalCode').innerText = f.remediation;
  document.getElementById('modalVerifyCmd').innerText = f.verification_cmd || `netstat -tuln | grep :${f.port}`;
  document.getElementById('fixModal').classList.add('active');
}

function closeModal() {
  document.getElementById('fixModal').classList.remove('active');
}

async function removeTarget(id) {
  if (!confirm('Remove target and correlated audit records?')) return;
  const res = await fetch(`/api/targets/${id}`, { method: 'DELETE' });
  if (res.ok) loadDashboard();
}

function downloadTxtReport() {
  if (localTargets.length === 0) {
    alert("Please enroll and audit a target first.");
    return;
  }

  const timestamp = new Date().toLocaleString();
  let content = "======================================================================\n";
  content += "             PENETRATION TESTING AUDIT REPORT                        \n";
  content += "             PTES Standard Lifecycle & Threat Feed Evidence           \n";
  content += "             Generated: " + timestamp + "\n";
  content += "======================================================================\n\n";

  content += "1. ASSESSMENT TARGETS IN SCOPE:\n";
  content += "----------------------------------------------------------------------\n";
  localTargets.forEach((t, idx) => {
    content += `[${idx + 1}] Host: ${t.name} | IP: ${t.ip} | Authorization: ${t.scope}\n`;
  });

  content += "\n2. TECHNICAL FINDINGS & SOCKET EVIDENCE:\n";
  content += "----------------------------------------------------------------------\n";
  localFindings.forEach((v, idx) => {
    content += `Finding #${idx + 1}: ${v.title} [${v.severity} - CVSS ${v.cvss}]\n`;
    content += `  - Status:             ${v.status}\n`;
    content += `  - CVE / Identifier:   ${v.cve}\n`;
    content += `  - CISA Exploited:     ${v.cisa_kev ? 'YES (In Wild Catalog)' : 'No'}\n`;
    content += `  - Port / Service:     TCP ${v.port} (${v.service})\n`;
    content += `  - Network Evidence:   ${v.evidence}\n`;
    content += `  - Terminal Fix:\n      ${v.remediation.replace(/\n/g, '\n      ')}\n\n`;
  });

  const blob = new Blob([content], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `PTES_Security_Audit_${new Date().toISOString().slice(0, 10)}.txt`;
  a.click();
}

document.getElementById('targetForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('targetName').value.trim(),
    ip: document.getElementById('targetIp').value.trim(),
    scope: document.getElementById('targetScope').value
  };

  const res = await fetch('/api/targets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (res.ok) {
    document.getElementById('targetName').value = '';
    document.getElementById('targetIp').value = '';
    loadDashboard();
  }
});

document.getElementById('filterSeverity').addEventListener('change', () => {
  renderFindings(localFindings);
});

window.addEventListener('DOMContentLoaded', loadDashboard);